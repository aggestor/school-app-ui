const o="/images/placeholder-no-prod.jpg";export{o as _};
