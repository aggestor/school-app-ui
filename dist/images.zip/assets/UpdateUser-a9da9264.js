import{_ as e}from"./index-4f0251ba.js";const r={};function t(c,s){return" div update user "}const n=e(r,[["render",t]]);export{n as default};
