import{_ as e,c,g as r}from"./index-4f0251ba.js";const t={};function n(s,o){return r(),c("div",null,"terms")}const a=e(t,[["render",n]]);export{a as default};
