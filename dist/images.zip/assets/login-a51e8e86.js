const s="/assets/login-4decc8d5.jpg";export{s as _};
