import"./index-4f0251ba.js";function o(a,r){const u=[];return a.data&&a.data.forEach(e=>{u.push({key:e[r.key],value:e[r.value]})}),u}export{o as u};
